from django.urls import path
from . import views


urlpatterns=[
    path("",views.index),
    path("home/",views.index),
    path("contact/",views.contact),
    path("gallery/",views.gallery),
    path("wchoose/",views.wchoose),
    path("team/",views.team),
    path("details/",views.details),
    path("course/",views.course),
    path("placement/",views.placement),
    path("facilities/",views.facilities),
    path("about/",views.about),


]