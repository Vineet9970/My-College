from django.shortcuts import render
from django.http import HttpResponse
from .models import *

# Create your views here.
def index(request):
    data=notice.objects.all()[0:4]
    d={"ndata":data}
    return render(request,"index.html",d)

def contact(request):
    d={}
    if request.method=="POST":
        a1=request.POST.get("name")#RAM
        a2=request.POST.get("email")#ABC@gmail.com
        a3=request.POST.get("mob")#234298462
        a4=request.POST.get("msg")#hello
        #d={"x1":name,"x2":email,"x3":mobile,"x4":message}
        contactus(name=a1,mobile=a3,email=a2,message=a4).save()
        return HttpResponse("<script>alert('data added Successfully..');location.href='/contact/';</script>")
    
    return render(request,"contact.html")

def gallery(request):
    data=igallery.objects.all()
    d={"gdata":data}
    return render(request,"gallery.html",d)


def wchoose (request):
    return render(request,"wchoose.html")

def team(request):
    data=ourfaculty.objects.all()# 2rows
    d={"fdata":data}
    return render(request,"team.html",d)

def details(request):
    return render(request,"details.html")

def about(request):
    return render(request,"about.html")

def facilities(request):
    data=myfacilities.objects.all()
    d={"gdata":data}

    return render(request,"facilities.html",d)

def placement(request):
    data=ourplacement.objects.all()
    d={"pdata":data}
    return render(request,"placement.html",d)

def course(request):
    data=mycourse.objects.all()
    d={"cdata":data}

    return render(request,"course.html",d)
